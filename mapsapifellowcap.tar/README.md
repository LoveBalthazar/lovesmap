Maps Javascript API Project Demonstration

This project is a basic demonstration of how Maps JavaScript API from GCP Marketplace can be incorporated into a website.

The website is for teaching and demonstration purposes. The HTML template (adapted from W3Schools) can be used as a base for your own project replacing the API key with yours, and of course using your creativity to design my capstone project. 

The website shows an example of how Maps JavaScript API is used to point to different cities surrounding New Orleans, Louisiana including markers.
